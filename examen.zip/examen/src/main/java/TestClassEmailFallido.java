import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestClassEmailFallido{
    //Rgistrar un cliente con un formato de correo incorrecto

    By Btnlogin= By.className("login");
    By email=By.id("email_create");
    By Btncuenta=By.id("SubmitCreate");

    public static void main(String[] args) {

        String resultado = new TestClassEmailFallido().pruebaAutomatica();
        System.out.println(resultado);
    }

    public String pruebaAutomatica(){

        System.setProperty("webdriver.chrome.driver","./src/test/resources/chormedriver/chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.get("http://automationpractice.com/index.php");
        driver.manage().window().maximize();

        //ir al boton registrar
        driver.findElement(Btnlogin).click();
        pausa(2000);

        //llenar el correo incorrecto
        driver.findElement(email).sendKeys("oskaruceda@gmailcom");

        //click boton crear cuenta
        driver.findElement(Btncuenta).click();
        pausa(2000);

        //Cerramos navegador
        driver.close();

        //resultado de la prueba
        return "Prueba Correcta";




    }

    public static void pausa(long sleeptime) {
        try {
            Thread.sleep(sleeptime);
        } catch (InterruptedException ex) {
        }
    }
}
