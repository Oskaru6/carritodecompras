import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import java.util.NoSuchElementException;

public class TestClassCart {
    By Btnlogin= By.className("login");
    By email=By.id("email");
    By password=By.id("passwd");
    By Btningresar=By.id("SubmitLogin");
    By menu=By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a");
    By category=By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/h5/a");
    By imagen=By.xpath("//*[@id=\"add_to_cart\"]/button");
    By Btnaddcard=By.className("shopping_cart");
    By Btncard=By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]");


    By BtnAddress=By.xpath("//*[@id=\"center_column\"]/form/p/button");
    By cgv= By.id("cgv");
    By Btncheckout=By.xpath("//*[@id=\"form\"]/p/button");
    By bankwire=By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a");

    By confirm= By.xpath("//*[@id=\"cart_navigation\"]/button");


    public static void main(String[] args) {

        String resultado = new TestClassCart().pruebacarrito();
        System.out.println(resultado);
    }

    public String pruebacarrito(){

        System.setProperty("webdriver.chrome.driver","./src/test/resources/chormedriver/chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.get("http://automationpractice.com/index.php");
        driver.manage().window().maximize();
       //WebDriverWait waitVar=new WebDriverWait(driver,10);

        //ir al boton registrar
        driver.findElement(Btnlogin).click();
        pausa(2000);

        //llenar el correo
        driver.findElement(email).sendKeys("ouceda@unprg.com.pe");

        //llenar el contraseña
        driver.findElement(password).sendKeys("12345678");

        //click boton login
        driver.findElement(Btningresar).click();




        driver.findElement(menu).click();
        driver.findElement(category).click();
        driver.findElement(imagen).click();
        driver.findElement(Btnaddcard).click();
        driver.findElement(Btncard).click();




        driver.findElement(BtnAddress).click();
        driver.findElement(cgv).click();
        driver.findElement(Btncheckout).click();
        driver.findElement(bankwire).click();
        driver.findElement(confirm).click();



        String textfinal= driver.findElement(By.className("dark")).getText();
        verificar(textfinal);

        //Cerramos navegador
        driver.close();

        //resultado de la prueba
        return "Prueba Correcta";

    }

    public static void pausa(long sleeptime) {
        try {
            Thread.sleep(sleeptime);
        } catch (InterruptedException ex) {
        }
    }

    public static void verificar(String textfinal) {
        try {

            System.out.println(textfinal.contains("Your order on My Store  is complete."));

        } catch (NoSuchElementException ne){
            System.err.println("Prueba Fallida");
        }
    }


}
