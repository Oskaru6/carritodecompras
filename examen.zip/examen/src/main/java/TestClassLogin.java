import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.NoSuchElementException;

public class TestClassLogin {
    By Btnlogin= By.className("login");
    By email=By.id("email");
    By password=By.id("passwd");
    By Btningresar=By.id("SubmitLogin");

    public static void main(String[] args) {

        String resultado = new TestClassLogin().pruebaAutomatica();
        System.out.println(resultado);
    }

    public String pruebaAutomatica(){

        System.setProperty("webdriver.chrome.driver","./src/test/resources/chormedriver/chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.get("http://automationpractice.com/index.php");
        driver.manage().window().maximize();

        //ir al boton registrar
        driver.findElement(Btnlogin).click();
        pausa(2000);

        //llenar el correo
        driver.findElement(email).sendKeys("ouceda1@unprg.com.pe");

        //llenar el contraseña
        driver.findElement(password).sendKeys("12345678");

        //click boton crear cuenta
        driver.findElement(Btningresar).click();
        pausa(2000);

        String textfinal= driver.findElement(By.id("my-account")).getText();
        verificar(textfinal);
        //Cerramos navegador
        driver.close();

        //resultado de la prueba
        return "Prueba Correcta";

    }

    public static void pausa(long sleeptime) {
        try {
            Thread.sleep(sleeptime);
        } catch (InterruptedException ex) {
        }
    }

    public static void verificar (String textfinal) {
        try {

            System.out.println(textfinal.contains("MY ACCOUNT")?textfinal:"Prueba Fallida!!!");

        } catch (NoSuchElementException ne){
            System.err.println("Prueba Fallida");
        }
    }

}
