import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestClassCorreoduplicado {
    //Rgistrar un correo que ya tiene  cuenta

    By Btnlogin= By.className("login");
    By email=By.id("email_create");
    By Btncuenta=By.id("SubmitCreate");

    public static void main(String[] args) {

        String resultado = new TestClassCorreoduplicado().pruebaAutomatica();
        System.out.println(resultado);
    }

    public String pruebaAutomatica(){

        System.setProperty("webdriver.chrome.driver","./src/test/resources/chormedriver/chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.get("http://automationpractice.com/index.php");
        driver.manage().window().maximize();

        //ir al boton registrar
        driver.findElement(Btnlogin).click();
        pausa(2000);

        //llenar el correo incorrecto
        driver.findElement(email).sendKeys("ouceda1@unprg.com.pe");

        //click boton crear cuenta
        driver.findElement(Btncuenta).click();
        pausa(2000);

        //Cerramos navegador
        driver.close();

        //resultado de la prueba
        return "Prueba Correcta";




    }

    public static void pausa(long sleeptime) {
        try {
            Thread.sleep(sleeptime);
        } catch (InterruptedException ex) {
        }
    }
}

