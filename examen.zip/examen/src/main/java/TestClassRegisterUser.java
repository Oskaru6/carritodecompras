import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

public class TestClassRegisterUser {

    //Caso: Rgistrar un cliente

        //variables primer formulario
        By Btnlogin= By.className("login");
        By email1=By.id("email_create");
        By Btncuenta=By.id("SubmitCreate");

        //variables Segundo formulario

        By Btntitle = By.id("id_gender1");
        By name= By.id("customer_firstname");
        By lastname= By.id("customer_lastname");
        By password=By.id("passwd");
        By days= By.id("days");
        By months=By.id("months");
        By year=By.id("years");
        By firstname=By.id("firstname");
        By lastname2=By.id("lastname");
        By company=By.id("company");
        By address=By.id("address1");
        By city=By.id("city");
        By state=By.id("id_state");
        By country=By.id("id_country");
        By postcode=By.id("postcode");
        By msje=By.id("other");
        By phone=By.id("phone");
        By alias=By.id("alias");
        By Btnregister=By.id("submitAccount");
        By cuenta=By.id("center_column");



        public static void main(String[] args) {

            String resultado = new TestClassRegisterUser().pruebaAutomatica();
            System.out.println(resultado);


        }

        public String pruebaAutomatica(){

            System.setProperty("webdriver.chrome.driver","./src/test/resources/chormedriver/chromedriver.exe");
            WebDriver driver= new ChromeDriver();
            driver.get("http://automationpractice.com/index.php");
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
            //ir al boton registrar
            driver.findElement(Btnlogin).click();
            pausa(2000);

            //llenar el correo correctamente

            driver.findElement(email1).sendKeys("ouceda6@unprg.com.pe");

            //click boton crear cuenta
            driver.findElement(Btncuenta).click();
            pausa(2000);

            //Llenado del Segundo Formulario
            driver.findElement(Btntitle).click();
            driver.findElement(name).sendKeys("oscar");
            driver.findElement(lastname).sendKeys("uceda");
            driver.findElement(password).sendKeys("12345678");
            driver.findElement(days).sendKeys("6");
            driver.findElement(months).sendKeys("June");
            driver.findElement(year).sendKeys("1990");
            driver.findElement(firstname).sendKeys("oscar");
            driver.findElement(lastname2).sendKeys("oscar");
            driver.findElement(company).sendKeys("choucair testing");
            driver.findElement(address).sendKeys("Circunvalacion Lima");
            driver.findElement(city).sendKeys("Lima");
            driver.findElement(state).sendKeys("Arizona");
            driver.findElement(postcode).sendKeys("85123");
            driver.findElement(country).sendKeys("United Sate");
            driver.findElement(msje).sendKeys("Hola deseo registrame para comprar");
            driver.findElement(phone).sendKeys("987654321");
            driver.findElement(alias).sendKeys("My address");
            driver.findElement(Btnregister).click();

            pausa(4000);
            String textfinal= driver.findElement(By.id("my-account")).getText();
            verificar(textfinal);


            //Cerramos navegador
            driver.close();

            //resultado de la prueba
            return "Prueba Correcta";

        }

        public static void pausa(long sleeptime) {
            try {
                Thread.sleep(sleeptime);
            } catch (InterruptedException ex) {
            }
        }


    public static void verificar (String textfinal) {
        try {

            System.out.println(textfinal.contains("MY ACCOUNT")?textfinal:"Prueba Fallida!!!");

        } catch (NoSuchElementException ne){
            System.err.println("Prueba Fallida");
        }
    }

    }


